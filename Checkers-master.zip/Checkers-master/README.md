# Checkers

## The main window of the game
<p align="center">
  <img src="https://i.imgur.com/pYgmz6B.jpg" width="250" title="hover text" alt="Main screen">
</p>

## A window with a list of saved game processes
<p align="center">
  <img src="https://i.imgur.com/ybhxc44.jpg" width="250" title="hover text" alt="Main screen">
</p>

Project. Completed by student CA - 32 : Dukhnych Yaroslav
