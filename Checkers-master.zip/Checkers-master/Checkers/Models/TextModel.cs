﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Checkers.Models
{
    public class TextModel
    {
        public int Id { get; set; }

        public string RulesText { get; set; }

        public string AboutText { get; set; }
    }
}
